<?php
require_once dirname(__DIR__) . '/vendor/autoload.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
use app\core\Application;
use app\controllers\SiteController;
use app\controllers\AuthController;
use app\controllers\ItdlhController;
$dotenv = Dotenv\Dotenv::createImmutable(dirname(__DIR__));
$dotenv->load();


$config = [
    'userClass' => \app\models\User::class,
    'appName' => $_ENV['DEFAULT_APP_NAME'] ?? 'Mandakini',
    'db' => [
        'dsn' => $_ENV['DB_DSN'] ?? 'mysql:host=localhost;port=3306;dbname=mandakini',
        'username' => $_ENV['DB_USER'] ?? 'root',
        'password' => $_ENV['DB_PASSWORD'] ?? ''
    ]
];


$app = new Application(dirname(__DIR__), $config);
Application::$app = $app;

$app->router->get('/', [SiteController::class, 'home']);
$app->router->get('/home', [SiteController::class, 'home']);
$app->router->get('/contact', [SiteController::class, 'contact']);
$app->router->post('/contact', [SiteController::class, 'contact']);
$app->router->get('/login', [AuthController::class, 'login']);
$app->router->post('/login', [AuthController::class, 'login']);
$app->router->get('/about', [SiteController::class, 'about']);
$app->router->get('/register', [AuthController::class, 'register']);
$app->router->post('/register', [AuthController::class, 'register']);
$app->router->get('/logout', [AuthController::class, 'logout']);
$app->router->get('/profile', [AuthController::class, 'profile']);
$app->router->get('/debug-session', [\app\controllers\DebugController::class, 'session']);

// ITDLH landing page (controller)
$app->router->get('/itdlh', [ItdlhController::class, 'index']);

// Optional API endpoint listing courses
$app->router->get('/itdlh/courses', [ItdlhController::class, 'courses']);

// Course detail pages (per-course routes)
$app->router->get('/itdlh/course/mso', [ItdlhController::class, 'course']);
$app->router->get('/itdlh/course/web', [ItdlhController::class, 'course']);
$app->router->get('/itdlh/course/python', [ItdlhController::class, 'course']);
$app->router->get('/itdlh/course/java', [ItdlhController::class, 'course']);
$app->router->get('/itdlh/course/php', [ItdlhController::class, 'course']);
$app->router->get('/itdlh/course/graphic', [ItdlhController::class, 'course']);
$app->router->get('/itdlh/course/english', [ItdlhController::class, 'course']);

// Protected download routes for course content (serve via controller)
$app->router->get('/itdlh/course/mso/download', [ItdlhController::class, 'download']);
$app->router->get('/itdlh/course/web/download', [ItdlhController::class, 'download']);
$app->router->get('/itdlh/course/python/download', [ItdlhController::class, 'download']);
$app->router->get('/itdlh/course/java/download', [ItdlhController::class, 'download']);
$app->router->get('/itdlh/course/php/download', [ItdlhController::class, 'download']);
$app->router->get('/itdlh/course/graphic/download', [ItdlhController::class, 'download']);
$app->router->get('/itdlh/course/english/download', [ItdlhController::class, 'download']);

echo $app->run();
