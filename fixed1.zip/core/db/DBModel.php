<?php
namespace app\core\db;
use app\core\Application;
use app\core\Model;

abstract class DBModel extends Model {
    abstract public static function tableName(): string;

    abstract public function attributes(): array;

    abstract public static function primaryKey(): string;


 
    public function save() {
        $tableName = static::tableName();
        $attributes = $this->attributes();
        $params = array_map(fn($attr) => ":$attr", $attributes);
        $statement = self::prepare("INSERT INTO $tableName (" . implode(',', $attributes) . ") VALUES (" . implode(',', $params) . ")");
        foreach ($attributes as $attribute) {
            $statement->bindValue(":$attribute", $this->{$attribute});
        }
        $statement->execute();
        return true;
    }

    public static function prepare($sql) {
        return Application::$app->db->pdo->prepare($sql);
    }

    public static function findOne($where) {
        $tableName = static::tableName();
        $attributes = array_keys($where);
        $sql = implode(" AND ", array_map(fn($attr) => "$attr = :$attr", $attributes));
        $statement = self::prepare("SELECT * FROM $tableName WHERE $sql");
        foreach ($where as $key => $item) {
            $statement->bindValue(":$key", $item);
        }
        $statement->execute();
        return $statement->fetchObject(static::class);
    }

    /**
     * Find all records optionally matching a where clause.
     *
     * Usage:
     *  - findAll() => returns all rows
     *  - findAll(['status' => 1]) => returns rows matching WHERE status = :status
     *  - findAll(['status' => 1], 'created_at DESC') => also applies ORDER BY
     *
     * @param array $where
     * @param string|null $orderBy
     * @return array An array of model instances
     */
    public static function findAll(array $where = [], string $orderBy = null): array {
        $tableName = static::tableName();

        if (empty($where)) {
            $sql = "SELECT * FROM $tableName";
        } else {
            $attributes = array_keys($where);
            $sqlWhere = implode(" AND ", array_map(fn($attr) => "$attr = :$attr", $attributes));
            $sql = "SELECT * FROM $tableName WHERE $sqlWhere";
        }

        if ($orderBy) {
            $sql .= " ORDER BY $orderBy";
        }

        $statement = self::prepare($sql);
        foreach ($where as $key => $item) {
            $statement->bindValue(":$key", $item);
        }
        $statement->execute();

        return $statement->fetchAll(\PDO::FETCH_CLASS, static::class);
    }
}