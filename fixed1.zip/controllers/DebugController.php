<?php
namespace app\controllers;

use app\core\Controller;
use app\core\Application;

class DebugController extends Controller {
    public function session() {
        header('Content-Type: text/plain');
        echo "--- \\$_SESSION ---\n";
        echo print_r($_SESSION, true);
        echo "\n\n--- Application::user ---\n";
        echo print_r(Application::$app->user, true);
        echo "\n";
    }
}
