<?php
namespace app\controllers;

use app\core\Application;
use app\core\Controller;
use app\core\Request;
use app\core\Response;
use app\models\ContactForm;


class SiteController extends Controller{
    public function home() {
        $param =[
            'name' => 'John Doe',
            'age' => 30,
        ];
        return $this->render('itdlh_landing', $param);
    }

    public function contact(Request $request) {
        $contactForm = new ContactForm();
        if ($request->isPost()) {
            $contactForm->loadData($request->getBody());
            if ($contactForm->validate() && $contactForm->send()) {
                Application::$app->session->setFlash('success', 'Thanks for contacting us!');

                // Process the form data (e.g., save to database, send email, etc.)
                return $this->render('contact', [
                    'message' => 'Form submitted successfully!',
                    'model' => $contactForm,
                ]);
            }
             return $this->render('contact', [
                'model' => $contactForm,
            ]);
        }
        return $this->render('contact', [
            'model' => $contactForm,
        ]);
      }

    public function handleContact(Request $request) {
         $body = $request->getBody();
         // Process the form data (e.g., save to database, send email, etc.)
        return $this->render('contact', [
            'message' => 'Form submitted successfully!'
        ]);
    }
    
    public function about(Request $request)
    {
        return $this->render('about');
    }
}

