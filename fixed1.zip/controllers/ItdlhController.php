<?php
namespace app\controllers;

use app\core\Controller;
use app\core\Application;
use app\core\exceptions\ForbiddenException;
use app\core\exceptions\NotFoundException;
use app\core\Request;

/**
 * Controller for ITDLH Kelaniya landing and related pages.
 */
class ItdlhController extends Controller
{
    /**
     * Show the ITDLH landing page.
     *
     * @param Request $request
     * @return string
     */
    public function index(Request $request)
    {
        return $this->render('itdlh_landing');
    }

    /**
     * Optional endpoint to list courses as JSON (API example).
     *
     * @param Request $request
     * @return string JSON
     */
    public function courses(Request $request)
    {
        $courses = [
            'MS Office Applications',
            'Web Designing',
            'Programming with Python',
            'Programming with Java',
            'Programming with PHP',
            'Graphic Designing',
            'Practical English',
        ];
        header('Content-Type: application/json');
        return json_encode($courses);
    }

    /**
     * Show a single course page based on the slug in the URL.
     * Expected paths: /itdlh/course/{slug}
     *
     * @param Request $request
     * @return string
     */
    public function course(Request $request)
    {
        $path = $request->getPath();
        $parts = explode('/', trim($path, '/'));
        $slug = end($parts);

        $map = [
            'mso' => [
                    'title' => 'MS Office Applications',
                    'description' => 'Comprehensive, practical training on Microsoft Office suite and essential desktop skills for workplace productivity. Course fee: Rs. 7,500.00.',
                    'image' => '/public/images/courses/mso.png',
                    'instructor' => 'L.A.S. Kumarasinghe',
                    'contents' => [
                        'Introduction',
                        'Windows OS',
                        'MS Word',
                        'MS Excel',
                        'MS PowerPoint',
                        'MS Access',
                        'Internet And Email',
                    ],
                    'duration' => '120 hours',
                    'certification' => 'Certification issued under the Ministry of Education of Sri Lanka',
            ],
            'web' => [
                'title' => 'Web Designing',
                'description' => 'Learn HTML, CSS, responsive design and modern frontend tooling to build attractive websites.',
                'image' => '/public/images/courses/web.webp'
            ],
            'python' => [
                'title' => 'Programming with Python',
                'description' => 'Intro to Python programming, data structures, scripting and practical projects.',
                'image' => '/public/images/courses/python.webp'
            ],
            'java' => [
                'title' => 'Programming with Java',
                'description' => 'Object-oriented programming, Java fundamentals and application development.',
                'image' => '/public/images/courses/java.jpg'
            ],
            'php' => [
                'title' => 'Programming with PHP',
                'description' => 'Server-side web development with PHP: building dynamic websites and simple APIs.',
                'image' => '/public/images/courses/php.jpg'
            ],
            'graphic' => [
                'title' => 'Graphic Designing',
                'description' => 'Design fundamentals, image editing and tools like Photoshop and Illustrator.',
                'image' => '/public/images/courses/graphic.jpg'
            ],
            'english' => [
                'title' => 'Practical English',
                'description' => 'Communicative English for students focusing on workplace and technical communication.',
                'image' => '/public/images/courses/english.jpg'
            ],
        ];

        $course = $map[$slug] ?? null;
        if (!$course) {
            header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
            return \app\core\Application::$app->router->renderView('_404');
        }

        return $this->render('itdlh_course', ['course' => $course, 'slug' => $slug]);
    }

    /**
     * Serve a protected course PDF download.
     * Expected path: /itdlh/course/{slug}/download
     * Only authenticated users may download.
     *
     * @param Request $request
     */
    public function download(Request $request)
    {
        // Determine slug from URL parts (second-to-last segment).
        $path = $request->getPath();
        $parts = explode('/', trim($path, '/'));
        // e.g. ['itdlh','course','mso','download'] => slug is at -2
        if (count($parts) < 3) {
            throw new NotFoundException();
        }
        $slug = $parts[count($parts) - 2];

        // Require authentication - redirect guests to login page
        if (Application::isGuest()) {
            Application::$app->response->redirect('/login');
            return;
        }

        $baseDir = Application::$ROOT_DIR . '/storage/course-content/';

        // Prefer single PDF named {slug}.pdf
        $storagePath = $baseDir . $slug . '.pdf';
        if (file_exists($storagePath)) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . basename($storagePath) . '"');
            header('Content-Length: ' . filesize($storagePath));
            readfile($storagePath);
            exit;
        }

        // If there's a directory with multiple files (e.g. storage/course-content/mso/*), create a zip and serve it
        $dirPath = $baseDir . $slug;
        if (is_dir($dirPath)) {
            // Require PHP Zip extension for zipping directories
            if (!class_exists('ZipArchive')) {
                throw new \Exception('Server configuration error: PHP Zip extension (ZipArchive) is not available. Enable the zip extension or place a single PDF at storage/course-content/' . $slug . '.pdf', 501);
            }

            $zipName = Application::$ROOT_DIR . '/runtime/' . $slug . '-content.zip';
            // Create zip archive
            $zip = new \ZipArchive();
            if ($zip->open($zipName, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) === true) {
                $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dirPath));
                foreach ($files as $file) {
                    if (!$file->isDir()) {
                        $filePath = $file->getRealPath();
                        $localPath = substr($filePath, strlen($dirPath) + 1);
                        $zip->addFile($filePath, $localPath);
                    }
                }
                $zip->close();

                header('Content-Type: application/zip');
                header('Content-Disposition: attachment; filename="' . basename($zipName) . '"');
                header('Content-Length: ' . filesize($zipName));
                readfile($zipName);
                // Remove temporary zip
                @unlink($zipName);
                exit;
            }
        }

        throw new NotFoundException();
    }
}
